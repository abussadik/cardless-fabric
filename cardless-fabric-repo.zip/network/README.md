Use fabric-samples/test-network. Deploy chaincode to channel 'domestic-payments'. Place app connection profile at app/server/connection.json.
